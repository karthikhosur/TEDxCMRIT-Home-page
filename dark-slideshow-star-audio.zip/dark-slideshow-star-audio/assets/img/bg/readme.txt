/***** YOU MAY REMOVE THIS readme.txt FILE AFTER READ *****/

img.jpg - image background
slideshow-*.jpg - slideshow image
video.jpg - video image
yt-video.jpg - youtube video image